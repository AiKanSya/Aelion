## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Tue May 26 2026 10:23:21 GMT+0200 (Central European Summer Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.22.0|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>Basic V2|
|**Service Type**<br>SAP System (ABAP On-Premise)|
|**Service URL**<br>https://s4hhost1.stms.fr:44300/sap/opu/odata/sap/ZFGI_FIORI_DEMO_SRV|
|**Module Name**<br>fgi_first_app_module_name|
|**Application Title**<br>FGI First App Application Title|
|**Namespace**<br>fr.stms|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.120.14|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>True, see https://www.npmjs.com/package/@sap-ux/eslint-plugin-fiori-tools#rules for the eslint rules.|

## fgi_first_app_module_name

FGI First App Description

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated application, run the following from the generated application root folder:

```
    npm start
```

- It is also possible to run the application using mock data that reflects the OData Service URL supplied during application generation.  In order to run the application with Mock Data, run the following from the generated app root folder:

```
    npm run start-mock
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


