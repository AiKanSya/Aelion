sap.ui.define(
    [
        "fr/stms/fgifirstappmodulename/controller/BaseController",
        "fr/stms/fgifirstappmodulename/libs/Formatter",
    ],
    (BaseController, Formatter) => {
        "use strict";

        return BaseController.extend(
            "fr.stms.fgifirstappmodulename.controller.Home",
            {
                formatter: Formatter,

                onInit: function () { },
            },
        );
    },
);