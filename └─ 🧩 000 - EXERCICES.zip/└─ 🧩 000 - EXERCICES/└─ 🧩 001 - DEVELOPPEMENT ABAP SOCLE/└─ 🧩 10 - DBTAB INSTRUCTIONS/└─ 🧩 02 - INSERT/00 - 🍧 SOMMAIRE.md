# 🌸 SOMMAIRE — └─ 🧩 02 - INSERT

## 🌺 EXERCICES

- [INSERT INTO](<./01 - 🍧 INSERT INTO.md>)
