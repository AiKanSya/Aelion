# 🌸 SOMMAIRE — └─ 🧩 02 - TRACES

## 🌺 EXERCICES

- [TRACES](<./01 - 🍧 TRACES.md>)
- [TRACES SQL](<./02 - 🍧 TRACES SQL.md>)
- [FICHIER DE TESTS](<./03 - 🍧 FICHIER DE TESTS.md>)
