# 🌸 EXERCICES — EXERCICES

<!-- GENERATED_EXERCISE_BANK -->

> Cours associé : [EXERCICES](<../../../└─ 🧩 005 - FIORI/└─ 🧩 06 - XML UI5/04 - 🍧 UI5 - CORRECTIONS.md>)

## 🌺 CONSIGNES

- Réaliser les exercices sans consulter le cours lors du premier essai.
- Produire une preuve vérifiable : code, résultat, capture ou explication structurée.
- Consulter le cours uniquement après avoir identifié précisément le blocage.
- Ne pas utiliser la solution de l'évaluation finale comme exemple.

## 🌺 EXERCICE 1 — RESTITUTION

Sans consulter le cours, définir **EXERCICES**, expliquer son utilité et citer une erreur d'utilisation possible.

## 🌺 EXERCICE 2 — MISE EN PRATIQUE

- [ ] Comparer la solution proposée avec sa propre démarche dans un exemple différent de celui du cours.
- [ ] Expliquer chaque étape de la correction dans un exemple différent de celui du cours.
- [ ] Identifier les erreurs possibles et leur cause dans un exemple différent de celui du cours.
- [ ] Reproduire la solution sans recopier le support dans un exemple différent de celui du cours.

## 🌺 EXERCICE 3 — DIAGNOSTIC

1. Construire volontairement un cas incorrect lié à **EXERCICES**.
2. Décrire le symptôme observable.
3. Identifier la cause technique ou fonctionnelle.
4. Corriger le cas et prouver la non-régression avec un cas nominal et un cas limite.

## 🌺 CRITÈRES DE VALIDATION

- [ ] Le résultat peut être expliqué sans relire le cours.
- [ ] L'exemple est exécutable ou vérifiable.
- [ ] Le cas d'erreur est distingué du cas nominal.
- [ ] Aucun élément propre à la solution de l'évaluation finale n'est utilisé.
